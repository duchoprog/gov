
fetch("https://api.propublica.org/congress/v1/115/senate/members.json", { headers: { "X-API-Key": " CLCkTrBF2iMWiWtvWcqXQvF8yRV2HMVtmRSSeB5L" } })
    .then(response => {
        return response.json()

    }
    )
    .then(json => {
        members = json.results[0].members
        app.members = members

        app.vmembers = members
        console.log("jjj", app.vmembers)

    })


var app = new Vue({
    el: '#app',
    data: {
        vmembers: [],
        checkedParties: ["R", "D", "I"],
        sel: "ALL",
        vestados: []
    },
    computed: {
        lealtad: function () {
            if (this.vmembers[0]) {
                let reps = { id: "R", name: "Republicans", cuantos: 0, leal: 0 }
                let dems = { id: "D", name: "Democrats", cuantos: 0, leal: 0 }
                let inds = { id: "I", name: "Independents", cuantos: 0, leal: 0 }
                let result = [reps, dems, inds]
                for (m = 0; m < this.vmembers.length; m++) {
                    if (this.vmembers[m].party == "R") {
                        reps.cuantos++
                        reps.leal += this.vmembers[m].votes_with_party_pct
                    } else if (this.vmembers[m].party == "D") {
                        dems.cuantos++
                        dems.leal += this.vmembers[m].votes_with_party_pct
                    } else if (this.vmembers[m].party == "I") {
                        inds.cuantos++
                        inds.leal += this.vmembers[m].votes_with_party_pct
                    }

                }
                for (r = 0; r < result.length; r++) {
                    result[r].leal = (result[r].leal / result[r].cuantos).toFixed(2)
                }

                return result
            }
        },
        faltantes: function () {

            let porFaltasDec = [...this.vmembers].sort((a, b) => b.missed_votes - a.missed_votes)
            if (porFaltasDec[2]) { console.log(porFaltasDec[0]) }

            let topFaltantes = []

            if (porFaltasDec[2]) {
                let i = 0
                console.log(porFaltasDec.length / 10)
                while (i < porFaltasDec.length / 10 || porFaltasDec[i + 1].missed_votes == porFaltasDec[i].missed_votes) {
                    topFaltantes.push(porFaltasDec[i])
                    topFaltantes[i].pc_falt = (topFaltantes[i].missed_votes * 100 / topFaltantes[i].total_votes).toFixed(2)


                    i++;
                }
                console.log(topFaltantes)
                return topFaltantes
            }

            return topFaltantes

        },



        votantes: function () {
            let porFaltas = [... this.vmembers].sort((a, b) => a.missed_votes - b.missed_votes)
            let topVotantes = []
            let v = 0
            while (v < porFaltas.length / 10 || porFaltas[v - 1].missed_votes == porFaltas[v].missed_votes) {
                topVotantes.push(porFaltas[v])
                topVotantes[v].pc_falt = (topVotantes[v].missed_votes * 100 / topVotantes[v].total_votes).toFixed(2)
                v++
            }

            return topVotantes

        },




        least: function () {
            let porInfiel = [... this.vmembers].sort((a, b) => a.votes_with_party_pct - b.votes_with_party_pct)
            let topInfiel = []
            let v = 0
            while (v < porInfiel.length / 10 || porInfiel[v - 1].votes_with_party_pct == porInfiel[v].votes_with_party_pct) {
                topInfiel.push(porInfiel[v])

                v++
            }

            return topInfiel

        },



        most: function () {
            let porFiel = [... this.vmembers].sort((a, b) => b.votes_with_party_pct - a.votes_with_party_pct)
            let topFiel = []
            let v = 0
            while (v < porFiel.length / 10 || porFiel[v - 1].votes_with_party_pct == porFiel[v].votes_with_party_pct) {
                topFiel.push(porFiel[v])

                v++
            }

            return topFiel

        },











        armarSelect: function () {
            estados = []
            for (m = 0; m < this.vmembers.length; m++) {
                if (estados.indexOf(this.vmembers[m].state) < 0) {
                    estados.push(this.vmembers[m].state)
                }

            }

            estados = estados.sort()
            estados.unshift("ALL")
            return estados
        },

        activados: function () {
            listaFiltrada = []

            checkados = this.checkedParties

            for (m = 0; m < this.vmembers.length; m++) {
                if (checkados.indexOf(this.vmembers[m].party) != -1 && (this.sel == "ALL" || this.sel == this.vmembers[m].state)) {
                    listaFiltrada.push(this.vmembers[m])


                }

            }
            return listaFiltrada
        }
    }
}
)
